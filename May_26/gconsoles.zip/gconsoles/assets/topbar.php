<?php
echo "<div class='topbari'>";//declares class
echo "<topbar>";

echo "<h1>gaming consoles</h1>";

echo "</topbar>";
echo "</div>";
?>